$(function () {
    $('.js-show-modal').on('click', function(event) {
       event.preventDefault();

        $('.js-modal').addClass('is-visible');

        $('.js-modal-overlay ').addClass('is-visible');
    });

    $('.js-modal-overlay').on('click', function (event) {
        $('.js-modal').removeClass('is-visible');
        $('.js-modal-overlay').removeClass('is-visible');
    })

    //hides the reply comment form in the parent comment
    $('.comment-reply').hide();
    $('.comment-reply-btn').click(function () {
    // $('.comment-reply-btn').click(function (event) {
    //     event.preventDefault();
    //     $(this).parent().next('.comment-reply').fadeToggle();
        $('.comment-reply').fadeToggle();
    });


    //hides the comment form till the button is clicked
    $(".comment-form").hide();
    $(".write-comment").click(function () {
        $('.comment-form').fadeToggle();
    });

//    Likes
    function updateText(btn, newCount, verb){
        btn.text(newCount + " " + verb);
        btn.attr('data-likes', newCount);
    }

    $(".like-btn").click(function(e){
        e.preventDefault();
        var this_ = $(this);
        var likeUrl = this_.attr("data-href");
        var likeCount = parseInt(this_.attr("data-likes")) | 0;
        var addLike = likeCount + 1;
        var removeLike = likeCount - 1;
        if (likeUrl){
            $.ajax({
                url: likeUrl,
                method: "GET",
                data: {},
                success: function(data){
                    console.log(data);
                    var newLikes;
                    if (data.liked){
                        updateText(this_, addLike, "Unlike")
                    } else {
                        updateText(this_, removeLike, "Like")
                    }
                }, error: function(error){
                    console.log(error);
                    console.log("error")
                }
            })
        }
    })

// //    jquery cookie for like and unlike button
//     var csrftoken = $.cookie('csrftoken'); // we read the value of the csrftoken cookie
//
//     //we check whether method is safe. Safe methods(GET,HEAD,OPTIONS,TRACE) don't require CSRF protection
//     function csrfSafeMethod(method) {
//     //    these HTTP methods do not require CSRF protection
//         return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
//     }
//     $.ajaxSetup({
//         /*before each ajax request is performed
//         * we check if the request method is safe and the current
//         * request is not cross-domain. If the request is unsafe, we set the X-CSRFToken
//         * header with the value obtained from the cookie. This setup will apply to all
//         * AJAX requests performed with jQuery.*/
//         beforeSend: function (xhr, settings) {
//             if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
//                 xhr.setRequestHeader("X-CSRFToken", csrftoken);
//             }
//         }
//     })


//    Chat form
//     $('#chat-form'.on("submit", function (event) {
//         event.preventDefault();
//
//         $.ajax({
//             url: '/post',
//             type: 'POST',
//             data: {msgbox: $('#chat-msg').val()},
//
//             success : function(json){
//                 $('#chat-msg').val('');
//                 $('#msg-list').append('<li class="text-right list-group-item">' + json.msg + '</li>');
//                 var chatlist = document.getElementById('msg-list-div');
//                 chatlist.scrollTop = chatlist.scrollHeight;
//             }
//         });
//     }))
//
//     function getMessages() {
//         if (!scrolling) {
//             $.get('/messages/', function (messages) {
//                 $('#msg-list').html(messages);
//                 var charlist = document.getElementById('msg-list-div');
//                 chatlist.scrollTop = chatlist.scrollHeight;
//             });
//         }
//         scrolling = false;
//     }
//
//     var scrolling = false;
//     $(function () {
//         $('#msg-list-div').on('scroll', function () {
//             scrolling = true
//         });
//         refreshTimer = setInterval(getMessages, 2500)
//     });
//
//     // $(f)
//     $('#send').attr('disabled', 'disabled');
//     $('#chat-msg').keyup(function () {
//         if($(this).val() != '') {
//             $('#send').removeAttr('disabled');
//         }
//     })



});




















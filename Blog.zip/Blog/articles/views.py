from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.http import Http404
from django.http import HttpResponseBadRequest, HttpResponse, HttpResponseRedirect
from django.http import HttpResponseForbidden
from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views.generic import RedirectView
from django.db.models import Q

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions

from .models import Post, Comment
from .forms import PostForm
from comment.forms import CommentForm
from taggit.models import Tag
from django.db.models import Count
from account.views import profile


# @login_required
def index(request, tag_slug=None):
    posts = Post.objects.all()
    tag = None

    if tag_slug:
        tag = get_object_or_404(Tag, slug=tag_slug)
        posts = posts.filter(tags__in=[tag])
    query = request.GET.get("query")
    if query:
        posts = posts.filter(
            Q(title__icontains=query) |
            Q(body__icontains=query) |
            Q(author__username__icontains=query) |
            Q(tags__name__in=[query])).distinct()
    paginator = Paginator(posts, 5)  # 3 posts in each page
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer deliver the first page
        posts = paginator.page(1)
    except EmptyPage:
        # If page is out of range deliver last page of results
        posts = paginator.page(paginator.num_pages)
    return render(request, 'articles/index.html', {'posts': posts,
                                                   'page': page,
                                                   'tag': tag,
                                                   'Tag': Tag})


def post_detail(request, year, month, day, post):
    post = get_object_or_404(Post, slug=post, #status='Published',
                             publish__year=year,
                             publish__month=month,
                             publish__day=day)
    page_user = get_object_or_404(User, username=post.author)
    initial_data = {
        'content_type': post.get_content_type,
        'object_id': post.id,
    }

    active_comment = post.comments.filter(active=True)

    form = CommentForm(request.POST or None, initial=initial_data)

    post_to_delete = request.POST.get('delete')
    if post_to_delete:
        post.delete()
        HttpResponseRedirect('index')

    if form.is_valid():
        content_type = form.cleaned_data.get('content_type')
        content_type = ContentType.objects.get(model=content_type)  # set it based from the model class
        obj_id = form.cleaned_data.get('object_id')
        content_data = form.cleaned_data.get('content')
        parent_obj = None
        try:
            parent_id = int(request.POST.get('parent_id'))
        except:
            parent_id = None

        if parent_id:
            parent_qs = Comment.objects.filter(id=parent_id)
            if parent_qs.exists() and parent_qs.count() == 1:
                parent_obj = parent_qs.first()
        new_comment, created = Comment.objects.get_or_create(user=request.user,
                                                             content_type=content_type,
                                                             object_id=obj_id,
                                                             comment=content_data,
                                                             parent=parent_obj)
        return HttpResponseRedirect(new_comment.content_object.get_absolute_url())
    comments = post.comments

    post_tags_ids = post.tags.values_list('id', flat=True)
    similar_posts = Post.objects.filter(tags__in=post_tags_ids).exclude(id=post.id)
    similar_posts = similar_posts.annotate(same_tags=Count('tags')).order_by('-same_tags', '-publish')[:4]

    return render(request, 'articles/detail.html', {'post': post,
                                                    'page_user': page_user,
                                                    'active_comment': active_comment,
                                                    'comments': comments,
                                                    'form': form,
                                                    'similar_posts': similar_posts})


@login_required
def write_post(request):
    if request.method == 'POST':
        post = Post(author=request.user)
        form = PostForm(data=request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = PostForm()
    return render(request, 'articles/add article.html',
                  {'form': form})


def edit_post(request, id=None):
    if id:
        post = get_object_or_404(Post, pk=id)
        if post.author != request.user:
            return HttpResponseForbidden()
    else:
        post = Post(author=request.user)

    form = PostForm(request.POST or None, instance=post)
    if request.POST and form.is_valid():
        form.save()
        return profile(request, request.user)
    return render(request, 'articles/add article.html', {'form': form})



@login_required
def delete_post(request, id):
    try:
        post = Post.objects.get(id=id)
    except:
        raise Http404

    if post.author != request.user:
        response = HttpResponse("You don't have permission to perform this action")
        response.status_code = 403
        return response

    if request.method == 'POST':
        # parent_obj_url = post.get_absolute_url()
        post.delete()
        messages.success(request, "This has been deleted")
        # return HttpResponseRedirect("index")
        return redirect("index")
    return render(request, "articles/confirm_post_delete.html", context={
        'object': post
    })


class PostLikeToggle(RedirectView):
    def get_redirect_url(self, *args, **kwargs):
        post = self.kwargs.get('post')
        year = self.kwargs.get('year')
        month = self.kwargs.get('month')
        day = self.kwargs.get('day')
        url_ = obj.get_absolute_url()
        user = self.request.user
        obj = get_object_or_404(Post, slug=post,
                                publish__year=year,
                                publish__month=month,
                                publish__day=day)
        if user.is_authenticated():
            if user in obj.likes.all():
                obj.likes.remove(user)
            else:
                obj.likes.add(user)
        else:
            return reverse("login")
        return url_


class PostLikeAPIToggle(APIView):
    authentication_classes = (authentication.SessionAuthentication,)
    permission_classes = (permissions.IsAuthenticated,)

    def get(self, request, year=None, month=None, day=None, post=None, format=None):
        obj = get_object_or_404(Post, slug=post,
                                publish__year=year,
                                publish__month=month,
                                publish__day=day)
        user = self.request.user
        updated = False
        liked = False
        if user.is_authenticated():
            if user in obj.likes.all():
                liked = False
                obj.likes.remove(user)
            else:
                liked = True
                obj.likes.add(user)
            updated = True
        else:
            return reverse("login")
        data = {
            "updated": updated,
            "liked": liked,
        }
        return Response(data)
from django import forms
from .models import Post
from pagedown.widgets import PagedownWidget


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title', 'body', 'status', 'tags')
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'body': PagedownWidget,
            'tags': forms.TextInput(attrs={'class': 'form-control'}),
        }

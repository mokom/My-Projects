from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.template.defaultfilters import slugify
from django.urls import reverse
from django.utils import timezone
from django.contrib.auth.models import User
from django.utils.encoding import python_2_unicode_compatible
from taggit.managers import TaggableManager

from comment.models import Comment


@python_2_unicode_compatible
class Post(models.Model):
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('published', 'Published'),)
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250, unique_for_date='publish')
    author = models.ForeignKey(User, related_name='blog_posts')
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    likes = models.ManyToManyField(User, blank=True, related_name='post_likes')
    tags = TaggableManager()

    class Meta:
        ordering = ('-publish',)

    def __str__(self):
        return self.title

    # Slugify the title and save the slug to db
    def save(self, *args, **kwargs):
        if not self.slug:
            slug_str = "%s" % (self.title.lower())
            self.slug = slugify(slug_str)
        super(Post, self).save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('post_detail',
                       args=[self.publish.year,
                             self.publish.strftime('%m'),
                             self.publish.strftime('%d'),
                             self.slug])

    def get_edit_url(self):
        return reverse("edit-post",
                       kwargs={"id": self.id})

    def get_delete_url(self):
        return reverse("delete_post", kwargs={"id": self.id})

    def get_like_url(self):
        return reverse("like-toggle",
                       kwargs={"year": self.publish.year,
                               "day": self.publish.strftime('%d'),
                               "post": self.slug,
                               "month": self.publish.strftime('%m')})

    def get_api_like_url(self):
        return reverse("like-api-toggle",
                       kwargs={"year": self.publish.year,
                               "day": self.publish.strftime('%d'),
                               "post": self.slug,
                               "month": self.publish.strftime('%m')})

    @property
    def comments(self):
        instance = self
        qs = Comment.objects.filter_by_instance(instance)
        return qs

    @property
    def get_content_type(self):
        instance = self
        content_type = ContentType.objects.get_for_model(instance.__class__)
        return content_type
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, update_session_auth_hash
from django.contrib.auth.models import User

from articles.models import Post
from .forms import SignupForm, UserForm, ProfileForm
from .forms import ChangePasswordForm


def register(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            User.objects.create_user(username=username, password=password, email=email)
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('index')
    else:
        form = SignupForm()
    return render(request, 'account/signup.html', {'form': form})



@login_required
def password(request):
    user = request.user
    if request.method == 'POST':
        form = ChangePasswordForm(request.POST)
        if form.is_valid():
            new_password = form.cleaned_data.get('new_password')
            user.set_password(new_password)
            user.save()
            update_session_auth_hash(request, user)
            messages.add_message(request, messages.SUCCESS,
                                 'Your password was successfully changed.')
            return redirect('password')

    else:
        form = ChangePasswordForm(instance=user)

    return render(request, 'account/password.html', {'form': form})


@login_required
def profile(request, username):
    page_user = get_object_or_404(User, username=username)
    posts = Post.objects.filter(author__username=page_user)
    return render(request, 'account/profile.html', {'page_user': page_user,
                                                    'posts': posts})


@login_required
def update_profile(request, username):
    page_user = get_object_or_404(User, username=username)
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=request.user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Profile updated successfully')
            # return redirect('profile')
            return profile(request, request.user)
        else:
            messages.error(request, 'Error updating your profile')
    else:
        user_form = UserForm(instance=request.user)
        profile_form = ProfileForm(instance=request.user.profile)
    return render(request, 'account/edit_profile.html',
                  {'user_form': user_form,
                   'profile_form': profile_form,
                   'page_user': page_user})





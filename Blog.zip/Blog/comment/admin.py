from django.contrib import admin
from .models import Comment


class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'content_object', 'comment', 'created', 'active')
    # list_display = ('user', 'post', 'comment', 'created', 'active')
    list_filter = ('active', 'created')
    search_fields = ('comment',)

admin.site.register(Comment, CommentAdmin)
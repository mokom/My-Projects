from django.conf.urls import url, include
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static


from account import views as account_views
from articles import views as articles_views

from django.contrib.sitemaps.views import sitemap
from articles.sitemaps import PostSitemap
from articles.feeds import LatestPostsFeed

sitemaps = {
    'posts': PostSitemap
}

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'^$', articles_views.index, name='index'),

    url(r'^login/', auth_views.login, {'template_name': 'account/login.html'}, name='login'),

    url(r'^logout/', auth_views.logout, {'next_page': '/'}, name='logout'),

    url(r'^signup/', account_views.register, name='signup'),

    url(r'^password/ ', account_views.password, name='password'),

    url(r'^add-post/$', articles_views.write_post, name='new-post'),

    url(r'^tag/(?P<tag_slug>[-\w]+)/$', articles_views.index,name='post_list_by_tag'),

    url(r'^(?P<year>\d{4})/(?P<month>\d{2})/(?P<day>\d{2})/(?P<post>[-\w]+)/$',
        articles_views.post_detail, name='post_detail'),

    url(r'^comments/', include('comment.urls'), name='comments'),

    url(r'^edit/(?P<id>\d+)/$',
        articles_views.edit_post, name='edit-post'),

    url(r'^(?P<year>\d{4})/(?P<month>\d{2})/(?P<day>\d{2})/(?P<post>[-\w]+)/delete/$',
        articles_views.delete_post, name='delete_post'),


    url(r'^(?P<id>\d+)/delete/$', articles_views.delete_post, name='delete_post'),

    url(r'^(?P<year>\d{4})/(?P<month>\d{2})/(?P<day>\d{2})/(?P<post>[-\w]+)/like/$',
        articles_views.PostLikeToggle.as_view(), name='like-toggle'),

    url(r'^api/(?P<year>\d{4})/(?P<month>\d{2})/(?P<day>\d{2})/(?P<post>[-\w]+)/like/$',
        articles_views.PostLikeAPIToggle.as_view(), name='like-api-toggle'),

    url(r'^sitemap\.xml$', sitemap, {'sitemaps': sitemaps},
        name='django.contrib.sitemaps.views.sitemap'),

    url(r'^feed/$', LatestPostsFeed(), name='post_feed'),

    url(r'^(?P<username>[^/]+)/$', account_views.profile, name='profile'),


    url(r'^(?P<username>[^/]+)/edit-profile/$', account_views.update_profile, name='edit_profile'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

from django import template

register = template.Library()

from django.db.models import Count
from articles.models import Post, Comment
from django.utils.safestring import mark_safe
import markdown


@register.simple_tag
def total_posts():
    return Post.objects.count()


@register.inclusion_tag('articles/latest_posts.html')
def show_latest_posts(count=10):
    latest_posts = Post.objects.order_by('-publish')[:count]
    return {'latest_posts': latest_posts}


@register.assignment_tag
def get_most_liked_posts(count=10):
    return Post.objects.annotate(
        total_likes=Count('likes')).order_by('-total_likes')[:count]

@register.assignment_tag
def get_most_commented_posts(count=10):
    return Comment.objects.annotate(
        total_comments=Count('comment')).order_by('-total_comments')[:count]


# @register.assignment_tag
# def get_tags():
#     return T

@register.filter(name='markdown')
def markdown_format(text):
    return mark_safe(markdown.markdown(text))
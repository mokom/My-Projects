from __future__ import unicode_literals
# from datetime import datetime
from django import template
from django.db.models.functions import datetime
from django.utils.translation import ugettext_lazy as _
from django.utils.timezone import now as tz_now



register = template.Library()

### FILTERS ###
@register.filter
def days_since(value):
    """ Returns number of days between today and value."""
    today = tz_now().date()
    if isinstance(value, datetime.datetime):
        value = value.date()
    diff = today - value
    if diff.days > 1:
        return _("%s days ago") % diff.days
    elif diff.days == 1:
        return _("yesterday")
    elif diff.days == 0:
        return _("today")
    else:
        # Date is in the future; return formatted date.
        return value.strftime("%B %d, %Y")